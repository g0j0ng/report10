package adb;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class AdbDAO {
	
	private Connection conn;
	private PreparedStatement pstmt;
	private ResultSet rs;
		
	//		---------- DB���� ----------  //
	public AdbDAO() {
		try {
			String dbURL = "jdbc:mysql://localhost:3306/Adb_db";//mysql ��ġ
			String dbID = "root";//mysql ID
			String dbPassword = "root";//mysql PASSWORD
			Class.forName("com.mysql.cj.jdbc.Driver");//���� ����̹�
			conn=DriverManager.getConnection(dbURL, dbID, dbPassword);//DB�������� �� ����
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	//�ڵ����� ��ȣ
	public int getNext() {
		String SQL = "SELECT ��ȣ FROM Adb ORDER BY ��ȣ DESC";
		try {
			PreparedStatement pstmt=conn.prepareStatement(SQL);
			rs=pstmt.executeQuery();
			if(rs.next()) {
				return rs.getInt(1) + 1;
			}else {
				return 1;
			}			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return -1;//����
	}
		
	//������
	public int write(Integer Number, String Name, String Phone) {
		String SQL = "INSERT INTO Adb VALUES(?,?,?)";
		try {
			PreparedStatement pstmt=conn.prepareStatement(SQL);
			pstmt.setInt(1, getNext());
			pstmt.setString(2, Name);
			pstmt.setString(3, Phone);
			return pstmt.executeUpdate();
		}catch (Exception e) {
			e.printStackTrace();
		}
		return -1;//�����ͺ��̽� ����
	}


		
	//���
	public ArrayList<Adb> getList(){
		String SQL = "SELECT * FROM Adb ORDER BY ��ȣ";                        
		ArrayList<Adb> list = new ArrayList<Adb>();
		try {
			PreparedStatement pstmt=conn.prepareStatement(SQL);
			rs=pstmt.executeQuery();
			while(rs.next()) {
				Adb adb = new Adb();
				adb.setNumber(rs.getInt(1));
				adb.setName(rs.getString(2));
				adb.setPhone(rs.getString(3));
				list.add(adb);
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}

	//�����б�
	 public Adb getAdb(int Number) {
		 String SQL = "SELECT * FROM Adb WHERE ��ȣ = ?";
		 try {
				PreparedStatement pstmt=conn.prepareStatement(SQL);
				pstmt.setInt(1, Number);
				rs=pstmt.executeQuery();
				if(rs.next()) {
					Adb adb = new Adb();
					adb.setNumber(rs.getInt(1));
					adb.setName(rs.getString(2));
					adb.setPhone(rs.getString(3));
					return adb;
				}
			}catch (Exception e) {
				e.printStackTrace();
			}
		 return null;
	 }
	 

}
