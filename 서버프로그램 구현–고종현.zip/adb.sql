drop database if exists Adb_db;

create database Adb_db;

use Adb_db;

create table Adb(
	번호 int,
	이름 varchar(50),
    전화번호 varchar(50),
	primary key(번호)
);


insert into Adb values (1,'이름1','111-1111-1111');
insert into Adb values (2,'이름2','222-2222-2222');




select * from Adb;